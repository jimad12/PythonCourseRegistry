#!/usr/bin/python

from distutils.core import setup

setup(name ='Student Course Registry',
version='1.0',
description='A simple Course Register GUI',
py_modules=['CourseRegistry']

)